TUG SQLite 이전 시험본

Unity 웹 빌드와 Node 서버를 함께 제공합니다.
기존 경기 기록을 data/scores.db에 포함했습니다.
Sky의 현재 지원 범위에 맞춰 초기화 SQL을 schema.sql로 옮기고 rounds_ended_at 인덱스만 제외했습니다.
테이블과 데이터는 원본과 같습니다. PostgreSQL 변환은 Sky에서 수행합니다.
게임 서버는 1개로 실행합니다. 진행 중 경기는 서버 메모리에 있습니다.
