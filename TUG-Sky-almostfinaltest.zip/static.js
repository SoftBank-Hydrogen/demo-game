"use strict";
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, 'public');
const types = { '.html': 'text/html; charset=utf-8', '.js': 'application/javascript', '.css': 'text/css', '.json': 'application/json', '.wasm': 'application/wasm', '.png': 'image/png', '.svg': 'image/svg+xml', '.ico': 'image/x-icon' };
function serveStatic(req, res) {
  if (!['GET', 'HEAD'].includes(req.method)) return false;
  let file;
  try {
    const relative = decodeURIComponent(new URL(req.url, 'http://localhost').pathname).replace(/^\/+/, '') || 'index.html';
    file = path.resolve(root, relative);
    if (!file.startsWith(root + path.sep) || !fs.statSync(file).isFile()) return false;
  } catch { return false; }
  // Unity's .unityweb files use the build's JavaScript decompression fallback.
  // Do not add Content-Encoding: gzip to these assets.
  res.writeHead(200, { 'Content-Type': types[path.extname(file)] || 'application/octet-stream', 'Content-Length': fs.statSync(file).size, 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' });
  if (req.method === 'HEAD') res.end();
  else fs.createReadStream(file).on('error', () => res.destroy()).pipe(res);
  return true;
}
module.exports = { serveStatic };
